﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Home
{
    public partial class Jobseekerlogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

            if (!IsPostBack)
            {
                lblError.Visible = false;
                Session["firstname"] = "";
                Session["lastname"]= "";
                Session["email"] = "";

              
            }
        }

        protected void btnSignin_Click(object sender, EventArgs e)
        {
            if(arecredentialsvalid(txtUsername.Text,txtPassword.Text))
            {
                lblError.Visible = false;
                assignAppDetails();
             
                Response.Redirect(@"~/Pages/Jobs_for_jobseekers.aspx");
            }
            else
            {
                lblError.Visible = true;
            }
        }



        public bool arecredentialsvalid(string struser,string strpass)
        {

            bool blnE = false;

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "ValiJobSeekerCredentials";
                cmd.Parameters.AddWithValue("@username", struser); 
                cmd.Parameters.AddWithValue("@passw", strpass);

                SqlParameter param = new SqlParameter("@isvalid", SqlDbType.Int);
                param.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(param);



                SqlParameter retval = cmd.Parameters.Add("@isvalid", SqlDbType.VarChar);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.ExecuteNonQuery();

                int retunvalue = (int)cmd.Parameters["@isvalid"].Value;

                if (retunvalue == 0)
                {
                    // Response.Write("usernotfound");
                }
                else
                {
                    blnE = true;
                }
                con.Close();

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }


            return blnE;
        }



        public void assignAppDetails()
        {
            try
            {
                SqlConnection con= new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());


                SqlDataReader reader;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select * from job_SeekReg where js_Email = '"+txtUsername.Text+"'";
                cmd.ExecuteNonQuery();
              

                reader = cmd.ExecuteReader();

                while(reader.Read())
                {
                    Session["firstname"] = reader.GetValue(1);
                    Session["lastname"] = reader.GetValue(3); ;
                    Session["email"] = txtUsername.Text;
                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void lnkforgotpwd_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Pages/Home/Forget_Password.aspx");
        }
    }
}



