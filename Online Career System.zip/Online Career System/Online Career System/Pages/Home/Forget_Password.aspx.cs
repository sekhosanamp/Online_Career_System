﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Home
{
    public partial class Forget_Password : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
   
        }

        protected void btnSignin_Click(object sender, EventArgs e)
        {
            if (checkifjobseekerExist(txtUsername.Text))
            {
                string strpassword = "";
                try
                {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from job_SeekReg where js_Email = '" + txtUsername.Text + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        strpassword = reader.GetValue(18).ToString();
                    }
                    reader.Close();
                    con.Close();
                    sendpassword(strpassword);
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
            else
            {
                string script = "alert(\"Username provided does not exist\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);

            }

        }

        public void sendpassword(string strpass)
        {
            System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
            mail.To.Add(txtUsername.Text);
            mail.From = new MailAddress("makhado23@gmail.com", "FeedBack for FindJobs career system", System.Text.Encoding.UTF8);
            mail.Subject = "Forget passord";
            mail.Subject = "Your Password is as below "  + strpass;
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("makhado23@gmail.com", "19941741");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            try
            {
                client.Send(mail);

                string script = "alert(\"Your password is successfully sent to your email\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }
            catch (Exception ex)
            {

                string script = "alert(\"An error has occured , we could'nt send you an email\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }
        }

        public bool checkifjobseekerExist(string email)
        {
            bool blnE = false;

            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "checkifjobseekerexist";
                cmd.Parameters.AddWithValue("@js_mail", email);


                SqlParameter param = new SqlParameter("@isexist", SqlDbType.Int);
                param.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(param);



                SqlParameter retval = cmd.Parameters.Add("@isexist", SqlDbType.VarChar);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.ExecuteNonQuery();

                int retunvalue = (int)cmd.Parameters["@isexist"].Value;

                if (retunvalue == 0)
                {
                    // Response.Write("usernotfound");
                }
                else
                {
                    blnE = true;
                }
                con.Close();

            }
            catch (Exception ex)
            {

            }


            return blnE;
        }
    }
}