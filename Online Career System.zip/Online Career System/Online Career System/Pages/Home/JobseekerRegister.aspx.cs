﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Home
{
    public partial class JobseekerRegister : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                lblError.Visible = false;
                Session["firstname"] = "";
                Session["lastname"] = "";
                Session["email"] = "";


            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           
        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            if (cmbLocation.SelectedIndex > 0)
            {
                if(isEmailValid(txtEmail.Text))
                {
                    if(ismatch(txtEmail.Text,txtConfirmEmail.Text))
                    {

                        //Check if user Exist
                       if (!checkifjobseekerExist(txtEmail.Text))
                        {
                        //Add a new Job Seeker

                          if(insertnewJobseekerData("","","","","","","","","","",cmbLocation.Text,"","","","",txtLname.Text,txtFname.Text,txtMiddleName.Text,txtEmail.Text,txtPass.Text))
                            {
                                assignAppDetails();
                                Response.Redirect(@"~/Pages/Jobs_for_jobseekers.aspx");
                                lblError.Visible = false;
                           }
                        }
                        else
                        {
                            lblError.Text = "You Already have an Account With us";
                            lblError.Visible = true;
                        }


                    }
                    else
                    {
                        lblError.Visible = true;
                        lblError.Text = "Your Emails Do not match";


                    }
                }
                else
                {
                    lblError.Visible = true;
                    lblError.Text = "Your Email Address is invalid , please Rectify";
                }

            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "Please select your Location";
            }
        }




        public bool isEmailValid(string email)
        {
            bool isval = false;

            if(email.Length>=4)
            { 
                if(email.Contains("@"))
                {
                    if(email.Contains("."))
                    {
                        isval = true;
                    }
                }

            }

            return isval;
        }


        public bool ismatch(string str1,string str2)
        {
            bool ism = false;

            if(str1.Equals(str2))
            {
                ism = true;
            }

            return ism;
        }

        public bool checkifjobseekerExist(string email)
        {
            bool blnE = false;

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd=new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "checkifjobseekerexist";
                cmd.Parameters.AddWithValue("@js_mail",email);


                SqlParameter param = new SqlParameter("@isexist", SqlDbType.Int);
                param.Direction = ParameterDirection.Output;
              
                cmd.Parameters.Add(param);



                SqlParameter retval = cmd.Parameters.Add("@isexist", SqlDbType.VarChar);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.ExecuteNonQuery();

               int retunvalue = (int)cmd.Parameters["@isexist"].Value;

                if(retunvalue==0)
                {
                   // Response.Write("usernotfound");
                }
                else
                {
                    blnE = true;
                }
                con.Close();

            }
            catch (Exception ex)
            {
               
            }


            return blnE;
        }



        public bool insertnewJobseekerData(string strhighQual,string strcurrentjobtit,string strnoticeperoid,string strliNKID,string strFacebook,string strGoogle,string  strTwitter,string strethencity,string contactnr,string stralterna,string strprovince,string strdisability,string ID_nr,string strnation,string strDOB,string lname,string fname,string middlename,string email,string passw)
        {
            bool isinserted = false;


            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                 cmd.CommandText = "InsertJobSeeker";


                cmd.Parameters.AddWithValue("@Email",email);
                cmd.Parameters.AddWithValue("@Fname",fname);
                cmd.Parameters.AddWithValue("@MiddleName",middlename);
                cmd.Parameters.AddWithValue("@Lname",lname);
                cmd.Parameters.AddWithValue("@Nationality",strnation);
                cmd.Parameters.AddWithValue("@ID_Nr", ID_nr);
                cmd.Parameters.AddWithValue("@AltNum",stralterna);
                cmd.Parameters.AddWithValue("@ContactNr", contactnr);
                    cmd.Parameters.AddWithValue("@Province", strprovince);
                cmd.Parameters.AddWithValue("@DOB", strDOB);
                cmd.Parameters.AddWithValue("@Ethencity", strethencity);
                cmd.Parameters.AddWithValue("@Disability", strdisability);
                cmd.Parameters.AddWithValue("@Notice_Period", strnoticeperoid);
                cmd.Parameters.AddWithValue("@Jobtitle",strcurrentjobtit);
                cmd.Parameters.AddWithValue("@Highest_Qual",strhighQual);
                cmd.Parameters.AddWithValue("@LinkDin",strliNKID);
                cmd.Parameters.AddWithValue("@Twitter", strTwitter);
                cmd.Parameters.AddWithValue("@Google",strGoogle);
               
                cmd.Parameters.AddWithValue("@password", passw);
                cmd.ExecuteNonQuery();
                isinserted = true;

            }
            catch (Exception ex )
            {
                Response.Write(ex.Message);
               
            }

            return isinserted;
        }


        public void assignAppDetails()
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                SqlDataReader reader;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select * from job_SeekReg where js_Email = '" + txtEmail.Text + "'";
                cmd.ExecuteNonQuery();


                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Session["firstname"] = reader.GetValue(1);
                    Session["lastname"] = reader.GetValue(3); ;
                    Session["email"] = txtEmail.Text;
                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}