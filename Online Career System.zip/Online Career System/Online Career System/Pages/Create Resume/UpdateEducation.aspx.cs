﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class UpdateEducation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
               string strqualid = Session["qualid"].ToString();



                try
                {


                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from Qualifications where Qual_ID = '" + strqualid + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        txtQualificationName.Text = reader.GetValue(1).ToString();
                        txtInstituition.Text= reader.GetValue(2).ToString();
                        cmbStatus.Text = reader.GetValue(3).ToString();
                       
                        listQualificLevel.Text = reader.GetValue(6).ToString();
                        Datetxt.Text = reader.GetValue(4).ToString();
                     


                    }
                    reader.Close();
                    con.Close();





                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }

            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbStatus.SelectedIndex > 0)
            {
                if (listQualificLevel.SelectedIndex > 0)
                {
                    lblError.Visible = false;

                    try
                    {

                        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "UpdateQualification";
                        cmd.Parameters.AddWithValue("@name", txtQualificationName.Text);
                        cmd.Parameters.AddWithValue("@Institution", txtInstituition.Text);
                        cmd.Parameters.AddWithValue("@progress", cmbStatus.Text);
                        cmd.Parameters.AddWithValue("@DateOfCompletion", Datetxt.Text);
                        cmd.Parameters.AddWithValue("@level", listQualificLevel.Text);
                        cmd.Parameters.AddWithValue("@qual_id", Session["qualid"].ToString());
                        cmd.ExecuteNonQuery();
                        con.Close();

                        string script = "alert(\"Qualification is successfully updated\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script, true);


                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }



                }
                else
                {
                    lblError.Text = "Please select Qualification level";
                    lblError.Visible = true;

                }
            }
            else
            {
                lblError.Text = "Please select the status ";
                lblError.Visible = true;
            }
        }
    }
}