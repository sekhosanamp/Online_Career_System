﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Career_Management
{
    public partial class Languages : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if(cmbSpeak.SelectedIndex>0)
            {
                if (cmbSpeak.SelectedIndex > 0)
                {
                    lblError.Visible = false;
                    try
                    {


                        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "InsertLanguagesProc";
                        cmd.Parameters.AddWithValue("@ln_Name1", txtlangauge.Text);
                        cmd.Parameters.AddWithValue("@ln_WrittenAblty1", cmbWrite.Text);
                        cmd.Parameters.AddWithValue("@ln_Spoken_Ability1", cmbSpeak.Text);
                        cmd.Parameters.AddWithValue("@js_Email1", Session["email"].ToString());
                        cmd.ExecuteNonQuery();

                        con.Close();

                        string script = "alert(\"Language is successfully saved\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script, true);


                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }
                else
                {
                    lblError.Text = "Please select your written level";
                    lblError.Visible = true;
                }
            }
            else
            {
                lblError.Text = "Please select your speak level";
                lblError.Visible = true;
            }
        }
    }
}