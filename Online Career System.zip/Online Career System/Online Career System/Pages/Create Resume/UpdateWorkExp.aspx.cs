﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class UpdateWorkExp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
        

                try
                {


                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from Work_Experience where we_id = '" + Session["expid"].ToString() + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                       txtJobTitle.Text = reader.GetValue(1).ToString();
                       txtCompany.Text = reader.GetValue(2).ToString();
                        chkSector.Text = reader.GetValue(3).ToString();

                        DrpjobType.Text = reader.GetValue(4).ToString();
                        txtResponsibilitie.Text = reader.GetValue(5).ToString();
                       txtstartDate.Text = reader.GetValue(6).ToString();
                       txtStopdate.Text = reader.GetValue(7).ToString();
 

                        if(reader.GetValue(8).ToString().Equals("Yes"))
                        {
                            chkStillHere.Checked = true;
                        }


                        txtSalary.Text = reader.GetValue(9).ToString();
                        txtlocation.Text = reader.GetValue(10).ToString();


                    }
                    reader.Close();
                    con.Close();





                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        protected void btnSave_Click1(object sender, EventArgs e)
        {
            string strstillWorhere = "No";
            if (chkStillHere.Checked)
            {
                strstillWorhere = "Yes";
            }
            if (DrpjobType.SelectedIndex == 0)
            {
                lblSelect.Visible = true;


            }
            else
            {

                try
                {



                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlCommand cmd = new SqlCommand();

                    con.Open();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "UpdateWorkExperience";
                    cmd.Parameters.AddWithValue("@Job_title", (txtJobTitle.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Job_Sector", chkSector.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Duties", (txtResponsibilitie.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Comp_name", (txtCompany.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Job_type", DrpjobType.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("Depart_reason", (txtlocation.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Start_date", (txtstartDate.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@End_date", (txtStopdate.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@StillHere", strstillWorhere);
                    cmd.Parameters.AddWithValue("@Salary", (txtSalary.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@ExperienceID", Session["expid"].ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    lblConfirm.Visible = false;
                    lblConfirm.Text = "Details are Submitted Successfully";
                    string script = "alert(\"Work Experince is successfully Updated\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);

                }

                catch (Exception ex)
                {

                    Response.Write(ex.Message);
                }

            }
        }

        protected void txtSalary_TextChanged(object sender, EventArgs e)
        {

        }
    }
}