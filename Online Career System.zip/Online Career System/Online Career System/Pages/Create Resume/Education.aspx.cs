﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class Education : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
     
        protected void btnSave_Click(object sender, EventArgs e)
        {



            if (cmbStatus.SelectedIndex > 0)
            {
                if (listQualificLevel.SelectedIndex > 0)
                {
                    lblError.Visible = false;

                    try
                    {

                        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "InsertQulification";
                        cmd.Parameters.AddWithValue("@name", txtQualificationName.Text);
                        cmd.Parameters.AddWithValue("@Institution", txtInstituition.Text);
                        cmd.Parameters.AddWithValue("@progress", cmbStatus.Text);
                        cmd.Parameters.AddWithValue("@DateOfCompletion", Datetxt.Text);
                        cmd.Parameters.AddWithValue("@level", listQualificLevel.Text);
                        cmd.Parameters.AddWithValue("@email", Session["email"].ToString());
                        cmd.ExecuteNonQuery();
                        con.Close();

                        string script = "alert(\"Qualification is successfully saved\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script, true);


                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }



                }
                else
                {
                    lblError.Text = "Please select Qualification level";
                    lblError.Visible = true;

                }
            }
            else
            {
                lblError.Text = "Please select the status ";
                lblError.Visible = true;
            }
        }
    }
}