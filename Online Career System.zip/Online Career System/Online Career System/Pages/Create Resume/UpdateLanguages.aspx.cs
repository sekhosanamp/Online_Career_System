﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class UpdateLanguages : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {


                try
                {


                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from langauges where ln_langid = '" + Session["langid"].ToString() + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        txtlangauge.Text = reader.GetValue(1).ToString();
                        cmbWrite.Text = reader.GetValue(2).ToString();
                        cmbSpeak.Text = reader.GetValue(3).ToString();

                     

                    }
                    reader.Close();
                    con.Close();





                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbSpeak.SelectedIndex > 0)
            {
                if (cmbSpeak.SelectedIndex > 0)
                {
                    lblError.Visible = false;
                    try
                    {


                        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "updateLanguagesProc";
                        cmd.Parameters.AddWithValue("@ln_Name1", txtlangauge.Text);
                        cmd.Parameters.AddWithValue("@ln_WrittenAblty1", cmbWrite.Text);
                        cmd.Parameters.AddWithValue("@ln_Spoken_Ability1", cmbSpeak.Text);
                        cmd.Parameters.AddWithValue("@ln_LangID1", Session["langid"].ToString());
                        cmd.ExecuteNonQuery();

                        con.Close();

                        string script = "alert(\"Language is successfully updated\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script, true);


                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }
                else
                {
                    lblError.Text = "Please select your written level";
                    lblError.Visible = true;
                }
            }
            else
            {
                lblError.Text = "Please select your speak level";
                lblError.Visible = true;
            }
        }
    }
}