﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Career_Management
{
    public partial class WorkExperience : System.Web.UI.Page
    {
        public object MessageBox { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {





            lblSelect.Visible = false;

        }

      

        protected void DrpjobType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)

        {
          

        }

        protected void chkSector_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void chkStillHere_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void txtStopdate_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click1(object sender, EventArgs e)
        {
            

            string strstillWorhere = "No";
            if(chkStillHere.Checked)
            {
                strstillWorhere = "Yes";
            }
            if (DrpjobType.SelectedIndex == 0)
            {
                lblSelect.Visible = true;


            }
            else
            {

                try
                {



                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                    SqlCommand cmd = new SqlCommand();

                    con.Open();
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "InsertWorkExperience";
                     cmd.Parameters.AddWithValue("@Job_title", (txtJobTitle.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Job_Sector", chkSector.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@Duties", (txtResponsibilitie.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Comp_name", (txtCompany.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Job_type", DrpjobType.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("Depart_reason", (txtlocation.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Start_date", (txtstartDate.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@End_date", (txtStopdate.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@StillHere", strstillWorhere);
                    cmd.Parameters.AddWithValue("@Salary", (txtSalary.Text.Trim()).ToString());
                    cmd.Parameters.AddWithValue("@Email", Session["email"].ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    lblConfirm.Visible = false;
                    lblConfirm.Text = "Details are Submitted Successfully";
                    string script = "alert(\"Work Experince is successfully Saved\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);

                }

                catch (Exception ex)
                {

                    Response.Write(ex.Message);
                }


            }
        }
    }
}