﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class PersonalInfo : System.Web.UI.Page
    {

       public static bool blncanupdate = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            string strEmail = Session["email"].ToString();


            //Retreive Data

            if (blncanupdate != true)
            {
              
            }

            if(!IsPostBack)
            {
                try
                {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from job_SeekReg where js_Email = '" + strEmail + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        txtFname.Text = reader.GetValue(1).ToString();
                        txtEmail.Text = Session["email"].ToString();
                        if (reader.GetValue(2).ToString().Length > 0)
                        {
                            txtMiddleName.Text = reader.GetValue(2).ToString();
                        }
                        txtLname.Text = reader.GetValue(3).ToString();

                        if (reader.GetValue(4).ToString().Length > 0)
                        {
                            cmbLocation.Text = reader.GetValue(4).ToString();

                        }


                        if (reader.GetValue(5).ToString().Length > 0)
                        {
                            txtTel.Text = reader.GetValue(5).ToString();
                        }


                        if (reader.GetValue(6).ToString().Length > 0)
                        {
                            txtAltNumber.Text = reader.GetValue(6).ToString();
                        }

                        if (reader.GetValue(7).ToString().Length > 0)
                        {
                            cmbNationality.Text = reader.GetValue(7).ToString();
                        }


                        if (reader.GetValue(8).ToString().Length > 0)
                        {

                            txtID.Text = reader.GetValue(8).ToString();

                        }


                        if (reader.GetValue(9).ToString().Length > 0)
                        {
                            txtDOB.Text = reader.GetValue(9).ToString();
                        }



                        if (reader.GetValue(10).ToString().Length > 0)
                        {
                            cmbRace.Text = reader.GetValue(10).ToString();
                        }



                        if (reader.GetValue(11).ToString().Length > 0)
                        {
                            cmdDisability.Text = reader.GetValue(11).ToString();
                        }



                        if (reader.GetValue(12).ToString().Length > 0)
                        {
                            cmbNoticePeriod.Text = reader.GetValue(12).ToString();
                        }



                        if (reader.GetValue(13).ToString().Length > 0)
                        {
                            txtJobTitle.Text = reader.GetValue(13).ToString();

                        }


                        if (reader.GetValue(14).ToString().Length > 0)
                        {
                            cmbHighestQualifi.Text = reader.GetValue(14).ToString();
                        }


                        if (reader.GetValue(15).ToString().Length > 0)
                        {

                            txtLinkURL.Text = reader.GetValue(15).ToString();
                        }


                        if (reader.GetValue(16).ToString().Length > 0)
                        {
                            txtTwitterURL.Text = reader.GetValue(16).ToString();

                        }



                        if (reader.GetValue(17).ToString().Length > 0)
                        {
                            txtGoogleURL.Text = reader.GetValue(17).ToString();

                        }

                    }
                    reader.Close();
                    con.Close();

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }


        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if(cmbLocation.SelectedIndex>0)
            {
               if(cmbRace.SelectedIndex>0)
                {
                if(cmdDisability.SelectedIndex > 0)
                    {
                     
                        if(cmbNationality.SelectedIndex>0)
                        {
                            if(cmbHighestQualifi.SelectedIndex>0)
                            {
                                if (cmbNoticePeriod.SelectedIndex > 0)
                                {
                                    lblError.Visible = false;

                                    if(txtEmail.Text.Equals(Session["email"].ToString()))
                                    {
                                        blncanupdate = true;
                                        if (UpdateJobseekerData(cmbHighestQualifi.Text, txtJobTitle.Text, cmbNoticePeriod.Text, txtLinkURL.Text, "", txtGoogleURL.Text, txtTwitterURL.Text, cmbRace.Text, txtTel.Text, txtAltNumber.Text, cmbLocation.Text, cmdDisability.Text, txtID.Text, cmbNationality.Text, txtDOB.Text, txtLname.Text, txtFname.Text, txtMiddleName.Text, txtEmail.Text))
                                        {
                                            string script = "alert(\"Personal Information is successfully updated\");";
                                            ScriptManager.RegisterStartupScript(this, GetType(),
                                                                  "ServerControlScript", script, true);

                                        }
                                    }
                                }
                                else
                                {
                                    lblError.Text = "Please Select your Notice Period";
                                    lblError.Visible = true;
                                }
                              
                            }
                            else
                            {
                                lblError.Text = "Please Select your Highest Qualification";
                                lblError.Visible = true;
                            }
                        }
                        else
                        {
                            lblError.Text = "Please Select your Nationality";
                            lblError.Visible = true;
                        }
                    }
                    else
                    {
                        lblError.Text = "Please Select either your  disable/not";
                        lblError.Visible = true;
                    }
                }
                else
                {
                    lblError.Text = "Please Select your Ethencity";
                    lblError.Visible = true;
                }
            }
            else
            {
                lblError.Text = "Please Select your Location";
                lblError.Visible = true;
            }
        }

        protected void txtFname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void cmbNationality_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbNationality.SelectedIndex==1)
            {
                txtID.Text = "";
                txtID.TextMode = TextBoxMode.SingleLine;
            }
        }


        public bool UpdateJobseekerData(string strhighQual, string strcurrentjobtit, string strnoticeperoid, string strliNKID, string strFacebook, string strGoogle, string strTwitter, string strethencity, string contactnr, string stralterna, string strprovince, string strdisability, string ID_nr, string strnation, string strDOB, string lname, string fname, string middlename, string email)
        {
            bool isinserted = false;


            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "UpdateJobSeeker";


                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Fname", fname);
                cmd.Parameters.AddWithValue("@MiddleName", middlename);
                cmd.Parameters.AddWithValue("@Lname", lname);
                cmd.Parameters.AddWithValue("@Nationality", strnation);
                cmd.Parameters.AddWithValue("@ID_Nr", ID_nr);
                cmd.Parameters.AddWithValue("@AltNum", stralterna);
                cmd.Parameters.AddWithValue("@ContactNr", contactnr);
                cmd.Parameters.AddWithValue("@Province", strprovince);
                cmd.Parameters.AddWithValue("@DOB", strDOB);
                cmd.Parameters.AddWithValue("@Ethencity", strethencity);
                cmd.Parameters.AddWithValue("@Disability", strdisability);
                cmd.Parameters.AddWithValue("@Notice_Period", strnoticeperoid);
                cmd.Parameters.AddWithValue("@Jobtitle", strcurrentjobtit);
                cmd.Parameters.AddWithValue("@Highest_Qual", strhighQual);
                cmd.Parameters.AddWithValue("@LinkDin", strliNKID);
                cmd.Parameters.AddWithValue("@Twitter", strTwitter);
                cmd.Parameters.AddWithValue("@Google", strGoogle);

             
                cmd.ExecuteNonQuery();
                isinserted = true;
                blncanupdate = false;
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);

            }

            return isinserted;
        }

    }
}