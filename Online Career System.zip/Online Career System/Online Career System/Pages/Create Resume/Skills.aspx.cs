﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class Skills1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            if(cmbexp.SelectedIndex>0)
            {
               if(cmbLevel.SelectedIndex>0)
                {
                    lblError.Visible = false;
                    try
                    {
                        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "InsertSkillsProc";
                        cmd.Parameters.AddWithValue("@sk_name1", txtskill.Text);
                        cmd.Parameters.AddWithValue("@sk_level1", cmbLevel.Text);
                        cmd.Parameters.AddWithValue("@sk_experience1", cmbexp.Text);
                        cmd.Parameters.AddWithValue("@js_Email", Session["email"].ToString());
                        cmd.ExecuteNonQuery();

                        con.Close();

                        string script = "alert(\"Skill is successfully saved\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script, true);


                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }
                else
                {
                    lblError.Visible = true;
                    lblError.Text = "Please select Skill level";

                }
            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "Please select Years of experience";
            }

          

        }
    }
}