﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class AttachMents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSignin_Click(object sender, EventArgs e)
        {



            if (FileUpload1.HasFile)
            {



                if (drpAttachmentType.SelectedIndex > 0)
                {
                    if (getsizeoffile() <= 6)
                    {
                     
                        lblError.Visible = false;




                        try
                        {
                            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                            con.Open();
                            SqlCommand cmd = new SqlCommand("InsertAttachmentProc", con);
                            cmd.CommandType = CommandType.StoredProcedure;


                            if (FileUpload1.HasFile)
                            {


                                string strname = FileUpload1.FileName.ToString();
                                string strextention = "";



                                int index = strname.LastIndexOf(".");
                                strextention = strname.Substring(index, strname.Length - index);

                            
                                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Attachments/") + getNewNameForAttachment() + strextention);
                                cmd.Parameters.AddWithValue("@at_type1", drpAttachmentType.Text);
                                cmd.Parameters.AddWithValue("@at_description1", txtDescription.Text);
                                cmd.Parameters.AddWithValue("@js_Email1", Session["email"].ToString());//
                                cmd.Parameters.AddWithValue("@at_attachment1", getNewNameForAttachment() + strextention);
                                cmd.Parameters.AddWithValue("@attachmentName", strname);
                                cmd.ExecuteNonQuery();
                                con.Close();

                                string script = "alert(\"Attachment succesdully added\");";
                                ScriptManager.RegisterStartupScript(this, GetType(),
                                                      "ServerControlScript", script, true);


                            }
                            else
                            {
                            }
                        }
                        catch (Exception ec)
                        {
                            Response.Write(ec.Message);

                        }

                    }
                    else
                    {
                        lblError.Visible = true;
                        lblError.Text = "File Size Exceeded 6 MB";
                    }
                }
                else
                {
                    lblError.Visible = true;
                    lblError.Text = "Please Choose your Attachment type";
                }





            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "Please Choose your file";
            }
        }


        public string getNewNameForAttachment()
        {
            string strname = "";
            int count = 0;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                SqlDataReader reader;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select * from Attachments where js_Email = '" + Session["email"].ToString() + "'";
                cmd.ExecuteNonQuery();


                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    count++;
                }
                reader.Close();
                con.Close();
            }
            catch (Exception ex)
            {
              //  Response.Write(ex.Message);
            }

            strname = Session["email"].ToString() + "Attachment" + count;
            return strname;
        }
        public double getsizeoffile()
        {
           
            double sizeinMB = FileUpload1.PostedFile.ContentLength;
            try
            {
              
   
                sizeinMB = sizeinMB / 1048576;
            }
            catch (Exception ex)
            {

                Response.Write(    ex.Message);
            }      
           

                return sizeinMB;
        }





    }




}