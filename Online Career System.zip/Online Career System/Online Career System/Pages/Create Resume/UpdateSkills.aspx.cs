﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Create_Resume
{
    public partial class UpdateSkills : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {


                try
                {


                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from skills where sk_id = '" + Session["skid"].ToString() + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        txtskill.Text = reader.GetValue(1).ToString();
                        cmbLevel.Text = reader.GetValue(2).ToString();
                        cmbexp.Text = reader.GetValue(3).ToString();



                    }
                    reader.Close();
                    con.Close();





                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            if (cmbexp.SelectedIndex > 0)
            {
                if (cmbLevel.SelectedIndex > 0)
                {
                    lblError.Visible = false;
                    try
                    {
                        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                        con.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "updateSkillsProc";
                        cmd.Parameters.AddWithValue("@sk_name1", txtskill.Text);
                        cmd.Parameters.AddWithValue("@sk_level1", cmbLevel.Text);
                        cmd.Parameters.AddWithValue("@sk_experience1", cmbexp.Text);
                        cmd.Parameters.AddWithValue("@sk_id1", Session["skid"].ToString());
                        cmd.ExecuteNonQuery();

                        con.Close();

                        string script = "alert(\"Skill is successfully updated\");";
                        ScriptManager.RegisterStartupScript(this, GetType(),
                                              "ServerControlScript", script, true);


                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }
                else
                {
                    lblError.Visible = true;
                    lblError.Text = "Please select Skill level";

                }
            }
            else
            {
                lblError.Visible = true;
                lblError.Text = "Please select Years of experience";
            }


        }
    }
}