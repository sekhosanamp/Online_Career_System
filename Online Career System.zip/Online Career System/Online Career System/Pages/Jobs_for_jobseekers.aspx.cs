﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages
{
    public partial class Jobs_for_jobseekers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Session["PostID"] = "";


                int count = 0;
                try
                {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from PostDetails";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        count += 1;
                    }
                    Label1.Text = count.ToString() + " Job(s) are Available";
                    reader.Close();
                    con.Close();



                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }
        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            DataList1.SelectedIndex = e.Item.ItemIndex;

            Session["PostID"] = ((Label)DataList1.SelectedItem.FindControl("PostIDLabel")).Text;
            Response.Redirect("ViewJob.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedIndex>0)
            {
                if(txtSearch.Text.Length>1)
                {
                    SqlDataSource1.FilterExpression = "(Posttitle like '%{0}%'  or Postref like '%{0}%') and Province = '" + DropDownList1.Text + "'";

                }
                else
                {
                    SqlDataSource1.FilterExpression = "Province = '{1}'";
                

                }




            }
            else
            {
                SqlDataSource1.FilterExpression = "Posttitle like '%{0}%'  or Postref like '%{0}%'";
            }
        }
    }
}