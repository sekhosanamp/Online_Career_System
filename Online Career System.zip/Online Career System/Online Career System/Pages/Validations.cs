﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Career_Management
{
    public class Validations
    {

        public int validatePassword(string txt1, string txt2)
        {
            int i = 1;

            if (txt1 != txt2)
            {
                return i = 1;
            }
            else return i = 0;

        }

        public int ValidatePhone(string PhoneNumber)
        {

            int valid = 0;
            int number = 0;

            if (int.TryParse(PhoneNumber, out number) && PhoneNumber.Length >= 5)
            {
                return valid = 0;
            }
            else
                return valid = 1;

        }


        public bool checkifjobseekerExist(string email)
        {
            bool blnE = false;

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "checkifCompanyexist";
                cmd.Parameters.AddWithValue("@js_mail", email);


                SqlParameter param = new SqlParameter("@isexist", SqlDbType.Int);
                param.Direction = ParameterDirection.Output;

                cmd.Parameters.Add(param);



                SqlParameter retval = cmd.Parameters.Add("@isexist", SqlDbType.VarChar);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.ExecuteNonQuery();

                int retunvalue = (int)cmd.Parameters["@isexist"].Value;

                if (retunvalue == 0)
                {
                    // Response.Write("usernotfound");
                }
                else
                {
                    blnE = true;
                }
                con.Close();

            }
            catch (Exception ex)
            {
                
            }


            return blnE;
        }



    }
}