﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class UpdatePost : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          if(!IsPostBack)
            {
                populateAuto();
                try
                {


                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from PostDetails where PostID = '" + Session["CompanyEmail"].ToString() + Session["PostRef"].ToString() + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        txtTitle.Text = reader.GetValue(1).ToString();
                        txtRef.Text = reader.GetValue(2).ToString();
                        txtDesc.Text = reader.GetValue(3).ToString();
                        txtRequi.Text = reader.GetValue(4).ToString();


                        try
                        {
                            string strSectors = reader.GetValue(5).ToString();


                            string line = strSectors;
                            string w;
                            int index;

                            for (int x = 0; x < 1000; x++)
                            {
                                index = line.IndexOf(",");
                                w = line.Substring(0, index);
                                foreach (ListItem lst in chkSector.Items)
                                {
                                    if (lst.Text.Equals(w))
                                    {
                                        lst.Selected = true;
                                    }

                                }
                                line = line.Remove(0, index + 1);

                            }
                        }
                        catch (Exception)
                        {


                        }

                        cmbProvince.Text = reader.GetValue(7).ToString();
                        DropDownList2.Text = reader.GetValue(8).ToString();
                        try
                        {

                            if (reader.GetValue(9).ToString() != "")
                            {
                                cmbpaytype.Text = reader.GetValue(9).ToString();
                            }

                        }
                        catch (Exception)
                        {

                            throw;
                        }

                        txtmimsal.Text = reader.GetValue(10).ToString();
                        txtMaxsal.Text = reader.GetValue(11).ToString();


                        try
                        {
                            if (reader.GetValue(12).ToString() != "")
                            {
                                chknigotiable.Checked = true;
                            }
                        }
                        catch (Exception)
                        {

                        }



                        try
                        {
                            string bonusline = reader.GetValue(13).ToString();

                            int index2;

                            for (int x = 0; x < 1000; x++)
                            {
                                index2 = bonusline.IndexOf(",");
                                string w = bonusline.Substring(0, index2);
                                foreach (ListItem lst in CheckBoxList1.Items)
                                {
                                    if (lst.Text.Equals(w))
                                    {
                                        lst.Selected = true;
                                    }

                                }
                                bonusline = bonusline.Remove(0, index2 + 1);

                            }

                        }
                        catch (Exception)
                        {


                        }


                        txtCommission.Text = reader.GetValue(15).ToString();
                        txtClsoingDate.Text = reader.GetValue(18).ToString();
                        cmbReceiveAppsType.Text = reader.GetValue(20).ToString();
                        TextBox1.Text = reader.GetValue(21).ToString();
                        txtOtherBonus.Text = reader.GetValue(26).ToString();
                        txtsearchable.Text = reader.GetValue(25).ToString();
                        cmbJobType.Text = reader.GetValue(27).ToString();
                        txtContact.Text = reader.GetValue(22).ToString();
                        txtContactName.Text = reader.GetValue(19).ToString();


                        try
                        {
                            foreach (ListItem lst in radOwnerShip.Items)
                            {
                                if (lst.Text.Equals(reader.GetValue(23).ToString()))
                                {
                                    lst.Selected = true;
                                }

                            }

                        }
                        catch (Exception)
                        {

                        }


                    }
                    reader.Close();
                    con.Close();





                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }



            }


        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {



        }

        protected void txtClsoingDate_TextChanged(object sender, EventArgs e)
        {

        }


        public void populateAuto()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
            SqlDataReader reader;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "Select * from AutoRejectionPost where PostID = '" + Session["CompanyEmail"].ToString() + Session["PostRef"].ToString() + "'";
            cmd.ExecuteNonQuery();


            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                cmbNation.Text = reader.GetValue(1).ToString();
                cmbAutoPro.Text = reader.GetValue(2).ToString();
                cmbMiniMumYears.Text = reader.GetValue(3).ToString();
                cmbMiniLevel.Text = reader.GetValue(4).ToString();
                cmbCovernote.Text = reader.GetValue(5).ToString();
                cmbGender.Text = reader.GetValue(6).ToString();


                if (reader.GetValue(6).ToString().ToUpper().Equals("YES"))
                {
                    chkRelocate.Checked = true;
                }

            }

            reader.Close();
            con.Close();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbReceiveAppsType.SelectedIndex == 0)
            {
                lblemail.Text = "Email Address for applications :";
            }
            else
            {
                lblemail.Text = "External Website for applications : ";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string pid = Session["companyemail"].ToString() + txtRef.Text;

            




                List<ListItem> selectedsectors = chkSector.Items.Cast<ListItem>().Where(li => li.Selected).ToList();
                string strjobsectors = "";


                foreach (ListItem mylist in selectedsectors)
                {
                    strjobsectors = strjobsectors + mylist.ToString() + ",";
                }



                List<ListItem> listbonuss = CheckBoxList1.Items.Cast<ListItem>().Where(li => li.Selected).ToList();
                string strbonuses = "";


                foreach (ListItem mylist in listbonuss)
                {
                    strbonuses = strbonuses + mylist.ToString() + ",";
                }

                if (selectedsectors.Count > 0)
                {


                    if (cmbProvince.SelectedIndex > 0)
                    {

                        if (cmbJobType.SelectedIndex > 0)
                        {
                            lblError.Visible = false;

                            bool checkifDatainserted = false;

                            string negotiable;
                            if (chknigotiable.Checked)
                            {
                                negotiable = "Negotiable Salary";
                            }
                            else
                            {
                                negotiable = "Non-negotiable";
                            }




                            try
                            {

                            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                            SqlCommand cmd = new SqlCommand();

                                con.Open();
                                cmd.Connection = con;
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.CommandText = "update_PostDetails";

                                cmd.Parameters.AddWithValue("@PostID", Session["companyemail"].ToString() + txtRef.Text);
                                cmd.Parameters.AddWithValue("@PostTitle", txtTitle.Text.Trim());
                                cmd.Parameters.AddWithValue("@searchable", txtsearchable.Text);
                                cmd.Parameters.AddWithValue("@otherbenefits", txtOtherBonus.Text);
                                cmd.Parameters.AddWithValue("@PostRef", txtRef.Text.Trim());
                                cmd.Parameters.AddWithValue("@JobDescDuties", txtDesc.Text.Trim());
                                cmd.Parameters.AddWithValue("@JobSectors", strjobsectors);
                                cmd.Parameters.AddWithValue("@Jobtype", cmbJobType.Text);
                                cmd.Parameters.AddWithValue("@CandidateRequirements", txtRequi.Text.Trim());
                                cmd.Parameters.AddWithValue("@Province", cmbProvince.Text);
                                cmd.Parameters.AddWithValue("@Location", DropDownList2.Text);
                                cmd.Parameters.AddWithValue("@Salary", cmbpaytype.Text);
                                cmd.Parameters.AddWithValue("@MinimumSalary", txtmimsal.Text.Trim());
                                cmd.Parameters.AddWithValue("@MaximumSalary", txtMaxsal.Text.Trim());
                                cmd.Parameters.AddWithValue("@NegotiableStatus", negotiable);
                                

                                cmd.Parameters.AddWithValue("@Bonuses", strbonuses);
                                
                                cmd.Parameters.AddWithValue("@BonusAmount", txtBonus.Text.Trim());
                                cmd.Parameters.AddWithValue("@Country", cmdCountry.Text);
                                cmd.Parameters.AddWithValue("@Commision", txtCommission.Text.Trim());
                                cmd.Parameters.AddWithValue("@OpenToDisable", cmddisability.Text);
                                cmd.Parameters.AddWithValue("@VacancyStatus", cmbVacanceStatus.Text);
                                cmd.Parameters.AddWithValue("@ClosingDate", txtClsoingDate.Text.ToString());
                                cmd.Parameters.AddWithValue("@ContactName", txtContactName.Text.Trim());
                                cmd.Parameters.AddWithValue("@ReceiveAppsVia", cmbReceiveAppsType.Text);
                                cmd.Parameters.AddWithValue("@EmailOrSiteForReceiv", TextBox1.Text.Trim());
                                cmd.Parameters.AddWithValue("@ContactNoApplication", txtContact.Text.Trim());
                                cmd.Parameters.AddWithValue("@AdOwnerShip", radOwnerShip.Text);
                                cmd.ExecuteNonQuery();
                                con.Close();
                                //lblConfirm.Visible = false;
                                //lblConfirm.Text = "Details are Submitted Successfully";
                                checkifDatainserted = true;

                            }
                            catch (Exception ex)
                            {

                                Response.Write(ex.Message);
                            }


                            //////////////////////////////////////////
                            ///Auto rejection table
                            //////////////////////////////////////////
                            if (checkifDatainserted)
                            {
                                updateAuto(Session["companyemail"].ToString() + txtRef.Text);
                                insertCountinfo();
                            }
                        }
                        else
                        {
                            lblError.Text = "Please select  Employment Contract Type";
                            lblError.Visible = true;
                        }







                    }
                    else
                    {
                        lblError.Visible = false;
                        lblError.Text = "Please select province";
                    }


                }

                else
                {
                    lblError.Text = "Please select the sector of your choice";
                    lblError.Visible = true;
                }

            









        }

        protected void chkSector_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void updateAuto(string postID)
        {
            try
            {

                string relocate = "No";

                if (chkRelocate.Checked)
                {
                    relocate = "Yes";
                }
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                SqlCommand cmd = new SqlCommand();

                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "updateAutoRejectionTable";
                cmd.Parameters.AddWithValue("@relocate", relocate);

                cmd.Parameters.AddWithValue("@Nationality", cmbNation.Text);
                cmd.Parameters.AddWithValue("@Province", cmbAutoPro.Text);
                cmd.Parameters.AddWithValue("@MinyearsofExp", cmbMiniMumYears.Text);
                cmd.Parameters.AddWithValue("@minleveofEducation", cmbMiniLevel.Text);
                cmd.Parameters.AddWithValue("@CoverNoteRequired", cmbMiniLevel.Text);
                cmd.Parameters.AddWithValue("@Gender", cmbCovernote.Text);
                cmd.Parameters.AddWithValue("@PostID", postID);
                cmd.ExecuteNonQuery();
                con.Close();
                //lblConfirm.Visible = false;
                //lblConfirm.Text = "Details are Submitted Successfully";

                if (cmbVacanceStatus.SelectedIndex == 0)
                {
                    string script = "alert(\"Post updated successfully  as a Draft\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);

                }
                else
                {
                    string script = "alert(\"Post is successfully updated  ,please note that it may take few hours before it goes live\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);

                }
            }
            catch (Exception ex)
            {

                Response.Write(ex.Message);
            }

        }

        protected void cmbProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbProvince.SelectedIndex)
            {
                case 0:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Please select the province");
                    }
                    break;
                case 1:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Johannesburg");
                        DropDownList2.Items.Add("Tshwane or Pretoria");
                        DropDownList2.Items.Add("East rand");
                        DropDownList2.Items.Add("Sandton");
                        DropDownList2.Items.Add("Randburg");
                        DropDownList2.Items.Add("Midrand");
                        DropDownList2.Items.Add("Centurion");
                        DropDownList2.Items.Add("Bryanston");
                        DropDownList2.Items.Add("Vaal Triangle");
                        DropDownList2.Items.Add("Soweto");
                        DropDownList2.Items.Add("West Rand");
                        DropDownList2.Items.Add("Johannesburg South");
                        DropDownList2.Items.Add("Johannesburg North");
                    }
                    break;
                case 2:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Bloemfontein");
                        DropDownList2.Items.Add("Welkom");
                        DropDownList2.Items.Add("Bethlehem");
                        DropDownList2.Items.Add("Harrismith");
                        DropDownList2.Items.Add("Ficksburg");
                        DropDownList2.Items.Add("Kroonstad");
                        DropDownList2.Items.Add("Parys");
                        DropDownList2.Items.Add("Sasolburg");

                    }
                    break;
                case 3:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Durban");
                        DropDownList2.Items.Add("Pietermaritzburg");
                        DropDownList2.Items.Add("Richards bay");
                        DropDownList2.Items.Add("Vryheid");
                        DropDownList2.Items.Add("Ladysmith");

                    }
                    break;
                case 4:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Standerton");
                        DropDownList2.Items.Add("Secunda");
                        DropDownList2.Items.Add("Witbank");
                        DropDownList2.Items.Add("Nelspruit");

                    }
                    break;
                case 5:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Polokwane");
                        DropDownList2.Items.Add("Louis Trichardt");
                        DropDownList2.Items.Add("Mokopane");
                        DropDownList2.Items.Add("Phalaborwa");
                        DropDownList2.Items.Add("Bela-Bela");

                    }
                    break;
                case 6:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Mahikeng");
                        DropDownList2.Items.Add("Klerksdorp");
                        DropDownList2.Items.Add("Rustenburg");
                        DropDownList2.Items.Add("Brits");
                        DropDownList2.Items.Add("Potchefstroom");

                    }
                    break;
                case 7:
                    {
                        DropDownList2.Items.Add("Kimberly");
                        DropDownList2.Items.Add("SpringBok");
                        DropDownList2.Items.Add("DeAar");
                        DropDownList2.Items.Add("Upington");

                    }
                    break;
                case 8:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Cape town");
                        DropDownList2.Items.Add("Paarl");
                        DropDownList2.Items.Add("Stellenbosch");
                        DropDownList2.Items.Add("Mossel bay");
                        DropDownList2.Items.Add("George");
                        DropDownList2.Items.Add("Somerset West");

                    }
                    break;
                case 9:
                    {
                        DropDownList2.Items.Clear();
                        DropDownList2.Items.Add("Port Elizabeth");
                        DropDownList2.Items.Add("East London");
                        DropDownList2.Items.Add("Grahamstown");
                        DropDownList2.Items.Add("Mthatha");
                        DropDownList2.Items.Add("Cradock");

                    }
                    break;
            }

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void chknigotiable_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            List<ListItem> selectedsectors = chkSector.Items.Cast<ListItem>().Where(li => li.Selected).ToList();


            if (selectedsectors.Count > 0)
            {
                Response.Write("yeboooooooooooo");
            }
            else
            {
                Response.Write("nonononono");
            }
        }



        //public bool checkifPostExist(string email)
        //{
        //    bool blnE = false;

        //    try
        //    {
        //        SqlConnection con = new SqlConnection("Data Source=HP\\SQLEXPRESS;Initial Catalog=CareerDB;Integrated Security=True");
        //        con.Open();
        //        SqlCommand cmd = new SqlCommand();
        //        cmd.Connection = con;
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cmd.CommandText = "checkifpostexist";
        //        cmd.Parameters.AddWithValue("@PostID", email);


        //        SqlParameter param = new SqlParameter("@exist", SqlDbType.Int);
        //        param.Direction = ParameterDirection.Output;

        //        cmd.Parameters.Add(param);



        //        SqlParameter retval = cmd.Parameters.Add("@exist", SqlDbType.Int);
        //        retval.Direction = ParameterDirection.ReturnValue;

        //        cmd.ExecuteNonQuery();

        //        int retunvalue = (int)cmd.Parameters["@exist"].Value;

        //        if (retunvalue == 0)
        //        {
        //            // Response.Write("usernotfound");
        //        }
        //        else
        //        {
        //            blnE = true;
        //        }
        //        con.Close();

        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write(ex.Message);
        //    }


        //    return blnE;
        //}

        public void insertCountinfo()
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "INSERTPOSTCOUNTSDETAILS";
                cmd.Parameters.AddWithValue("@NO_OF_APPS", 0);
                cmd.Parameters.AddWithValue("@NO_OF_VIEWS", 0);
                cmd.Parameters.AddWithValue("@PID", Session["Companyemail"].ToString() + txtRef.Text);

                cmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {

            }

        }
    }



}