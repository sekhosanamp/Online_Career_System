﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class ViewJoseekrProf : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!IsPostBack)
                {

                    txtSearch.Text = Session["email2"].ToString();
                    viewpersonalinformation();

                }
            }
            catch (Exception)
            {

             
            }




        }






        public void viewpersonalinformation()
        {

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                SqlDataReader reader;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select * from job_SeekReg where js_Email = '" + Session["email2"].ToString() + "'";
                cmd.ExecuteNonQuery();


                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    string strfname = "First Name".PadRight(27, Convert.ToChar(160)) + reader.GetValue(1).ToString() + "<br />";
                    lblPersonalInformation.Text = strfname;
                    if (reader.GetValue(2).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Middle Name".PadRight(27, Convert.ToChar(160)) + reader.GetValue(2).ToString() + "<br />";
                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Middle Name".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }
                    lblPersonalInformation.Text = lblPersonalInformation.Text + "Last Name".PadRight(27, Convert.ToChar(160)) + reader.GetValue(3).ToString() + "<br />";



                    if (reader.GetValue(4).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Province".PadRight(27, Convert.ToChar(160)) + reader.GetValue(4).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Province".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }

                    lblPersonalInformation.Text = lblPersonalInformation.Text + "Email".PadRight(27, Convert.ToChar(160)) + Session["email2"].ToString() + "<br />";




                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Province".PadRight(27, Convert.ToChar(160)) + reader.GetValue(5).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Province".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }



                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Alternative Number".PadRight(27, Convert.ToChar(160)) + reader.GetValue(6).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Alternative Number".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Nationality".PadRight(27, Convert.ToChar(160)) + reader.GetValue(7).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Nationality".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "ID Number".PadRight(27, Convert.ToChar(160)) + reader.GetValue(8).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "ID Number".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "DOB".PadRight(27, Convert.ToChar(160)) + reader.GetValue(9).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "DOB".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Ethencity".PadRight(27, Convert.ToChar(160)) + reader.GetValue(10).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Ethencity".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }



                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Disability".PadRight(27, Convert.ToChar(160)) + reader.GetValue(11).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Disability".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Notice Period".PadRight(27, Convert.ToChar(160)) + reader.GetValue(12).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Notice Period".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }

                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Current Job".PadRight(27, Convert.ToChar(160)) + reader.GetValue(13).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Current Job".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Highest Qualification".PadRight(27, Convert.ToChar(160)) + reader.GetValue(14).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Highest Qualification".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }


                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "LinkedIn Profile URl".PadRight(27, Convert.ToChar(160)) + reader.GetValue(15).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "LinkedIn Profile URl".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }



                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Twitter Profile URl".PadRight(27, Convert.ToChar(160)) + reader.GetValue(16).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Twitter Profile URl".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }



                    if (reader.GetValue(5).ToString().Length > 0)
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Google+ Profile URl".PadRight(27, Convert.ToChar(160)) + reader.GetValue(17).ToString() + "<br />";

                    }
                    else
                    {
                        lblPersonalInformation.Text = lblPersonalInformation.Text + "Google+ Profile URl".PadRight(27, Convert.ToChar(160)) + "Not Provided" + "<br />";

                    }

                }
                reader.Close();
                con.Close();

        }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

}

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
          
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
        
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
          
        }

        protected void LinkButton6_Click(object sender, EventArgs e)
        {
         
        }

        protected void DataList2_ItemCommand(object source, DataListCommandEventArgs e)
        {




        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
         
        }

        protected void DataList2_ItemCommand1(object source, DataListCommandEventArgs e)
        {
            try
            {
                }
            catch (Exception)
            {


            }
        }

        protected void DataList3_ItemCommand(object source, DataListCommandEventArgs e)
        {

        }

        protected void DataList4_EditCommand(object source, DataListCommandEventArgs e)
        {


        }

        protected void DataList4_ItemCommand(object source, DataListCommandEventArgs e)
        {
          
        }

        protected void DataList5_ItemCommand(object source, DataListCommandEventArgs e)
        {
         
        }
    }
}