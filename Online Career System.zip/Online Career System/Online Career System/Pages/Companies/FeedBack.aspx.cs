﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class FeedBack : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "insertFeedback";

                cmd.Parameters.AddWithValue("@subj", "Feed Back from Company");
                cmd.Parameters.AddWithValue("@desc ", txtDescription.Text);
                cmd.Parameters.AddWithValue("@js_email", Session["companyemail"].ToString());

                cmd.ExecuteNonQuery();
                con.Close();

                string script = "alert(\"FeedBack is successfully sent ,Thank you for your time\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);

                txtDescription.Text = "";

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                string script = "alert(\"An error has occured , we could'nt receive your feedback please try again later\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtDescription.Text = "";
        }
    }
}