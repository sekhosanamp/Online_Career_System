﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class ContactUs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnSend_Click(object sender, EventArgs e)
        {
 
          
            SqlCommand cmd;




            try
            {

                if (drpContact.SelectedIndex == 1)
                {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    con.Open();
                    cmd = new SqlCommand("uspContactUs", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@nme", txtname.Text);
                    cmd.Parameters.AddWithValue("@email", txtemail.Text);
                    cmd.Parameters.AddWithValue("@subject", txtSubject.Text);
                    cmd.Parameters.AddWithValue("@msg", txtmessage.Text);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    string script = "alert(\"Thank you for your valuable feedback... \");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);

                }
                else if (drpContact.SelectedIndex == 2)
                {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    con.Open();
                    cmd = new SqlCommand("uspContactUsCompany", con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@nme", txtname.Text);
                    cmd.Parameters.AddWithValue("@email", txtemail.Text);
                    cmd.Parameters.AddWithValue("@subject", txtSubject.Text);
                    cmd.Parameters.AddWithValue("@msg", txtmessage.Text);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    string script = "alert(\"Thank you for the  valuable feedback from your company \");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);
                }
                else if (drpContact.SelectedIndex == 0)
                {
                    string script = "alert(\"Please select if you are a job seeker or company representative\");";
                    ScriptManager.RegisterStartupScript(this, GetType(),
                                          "ServerControlScript", script, true);
                }

            }
            catch (Exception ex)
            {
                string script = "alert(\" '" +ex.Message +"'\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }





        }
    }
}