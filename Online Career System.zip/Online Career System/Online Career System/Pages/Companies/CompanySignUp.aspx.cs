﻿using Career_Management;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class CompanySignUp : System.Web.UI.Page
    {
    
        SqlCommand cm;


        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            ValidateTexts();
            Validations va = new Validations();

          
            if (lblError.Text == "")
            {
                if (va.checkifjobseekerExist(txtEmail.Text))
                {
                    lblError.Text = "Company profile already exist";
                }
                else
                {
                    InsertCompany();
                    Session["companyemail"] = txtEmail.Text;
                    Session["companyname"] = txtCompanyname.Text;
                    Response.Redirect("~/Pages/Companies/CompanyPosts.aspx");
                }
                 
            }


        }
        public void InsertCompany()
        {


            try
            {

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                con.Open();
                cm = new SqlCommand("InsertCompany", con);
                cm.CommandType = CommandType.StoredProcedure;

                cm.Parameters.AddWithValue("@email", txtEmail.Text);
                cm.Parameters.AddWithValue("@CompanyName", txtCompanyname.Text);
                cm.Parameters.AddWithValue("@FirstName", txtFirstname.Text);
                cm.Parameters.AddWithValue("@LastName", txtLstname.Text);
                cm.Parameters.AddWithValue("@Registration", txtRegNum.Text);
               
                    try
                    {
                        if (FileUpload1.HasFile)
                        {
                            string strname = FileUpload1.FileName.ToString();
                            string strextention = "";

                            int index = strname.LastIndexOf(".");
                            strextention = strname.Substring(index, strname.Length - index);
                            Response.Write(strextention);
                            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/CompanyLogo/") + txtEmail.Text +"Logo" + strextention);
                            cm.Parameters.AddWithValue("@Companylogo", txtEmail.Text + "Logo" + strextention);

                    }
                        else
                        {
                        }
                    }
                    catch (Exception ec)
                    {

                        Response.Write(ec.Message);

                    }

                 
               
              
                cm.Parameters.AddWithValue("@ContactNo", txtTelNum.Text);
                cm.Parameters.AddWithValue("@Website", txtWebsite.Text);
                cm.Parameters.AddWithValue("@physicaladdress", txtAdress.Text);
                cm.Parameters.AddWithValue("@Country", drpCountry.SelectedValue.ToString());
                cm.Parameters.AddWithValue("@Province", drpProvince.SelectedValue.ToString());
                cm.Parameters.AddWithValue("@Zipcode", txtZipCode.Text);
                cm.Parameters.AddWithValue("@Password", txtPasswd.Text);
                cm.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {

                lblError.Text = ex.Message;
            }

        }
        public void ValidateTexts()
        {
            Validations va = new Validations();

            //validate password
            int res = va.validatePassword(txtPasswd.Text, txtConfPasswd.Text);
            if (res == 1)
            {
                lblError.Text = "Passwords are not matching , Please correct";

                txtPasswd.Focus();
            }
            else
                lblError.Text = "";


            //validate matching emails

            int em = va.validatePassword(txtEmail.Text, txtConfEmail.Text);
            if (em == 1)
            {
                lblError.Text = "emails are not matching , Please correct";
            }
            else lblError.Text = "";

            //make sure that a country has been selected
            if (drpCountry.Text == "Select Country")
            {
                lblError.Text = "Please select country";
            }

            ////validate registration number >=5 numbers only
            //int res2 = va.ValidatePhone(txtRegNum.Text);
            //if (res2 == 1)
            //{
            //    lblError.Text = "Invalid Registration number ";
            //}


            //accept our terms and conditions
            if (!chkAcceptTerms.Checked)
            {
                lblError.Text = "Please Accept our Terms and Conditions before proceeding";

            }



        }



        protected void btnBrowse_Click(object sender, EventArgs e)
        {


        }

        protected void drpProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            drpProvince.Focus();
        }

        protected void drpCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drpCountry.SelectedIndex == 1)
            {
                drpProvince.Items.Clear();
                drpProvince.Items.Add("Mpumalanga");
                drpProvince.Items.Add("Gauteng");
                drpProvince.Items.Add("Free State");
                drpProvince.Items.Add("Limpopo");
                drpProvince.Items.Add("Northern Cape");
                drpProvince.Items.Add("Wesstern Cape");
                drpProvince.Items.Add("Eatsern Cape");
                drpProvince.Items.Add("Kwa -Zulu Natal");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Session["companyemail"] = "";
                Session["companyname"] = "";

            }
        }
    }
}
