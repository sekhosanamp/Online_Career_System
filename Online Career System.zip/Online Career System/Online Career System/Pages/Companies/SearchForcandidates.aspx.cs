﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class SearchForcandidates : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                int count = 0;
                try
                {
                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from job_SeekReg";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        count += 1;
                    }
                    Label1.Text = count.ToString() + " Job Seeker(s) are Available";
                 reader.Close();
                    con.Close();
                 


                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
            }

        }

        protected void Image1_Click(object sender, ImageClickEventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           if(DropDownList1.SelectedIndex==2)
            {
                SqlDataSource1.FilterExpression = "js_Highest_Qual like '%{0}%'";
                GridView2.Visible = false;
                GridView3.Visible = false;
                GridView4.Visible = false;
                GridView1.Visible = true;

            }


           if(DropDownList1.SelectedIndex==0)
            {
                SqlDataSource3.FilterExpression = "sk_name like '%{0}%'";
                GridView1.Visible = false;
                GridView2.Visible = true;
                GridView3.Visible = false;
                GridView4.Visible = false;
            }


           if(DropDownList1.SelectedIndex==1)
            {
                SqlDataSource2.FilterExpression = "Qual_name like '%{0}%' or Qual_Institution like '%{0}%'";
                GridView1.Visible = false;
                GridView2.Visible = false;
                GridView3.Visible = true;
                GridView4.Visible = false;

            }


           if(DropDownList1.SelectedIndex==3)
            {
                SqlDataSource4.FilterExpression = "we_job_title like '%{0}%' or we_comp_name like '%{0}%'";
                GridView1.Visible = false;
                GridView2.Visible = false;
                GridView3.Visible = false;
                GridView4.Visible = true;
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["email2"] = GridView1.SelectedRow.Cells[4].Text;
            Response.Redirect("~/Pages/Companies/ViewJoseekrProf.aspx");
        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["email2"] = GridView2.SelectedRow.Cells[4].Text;
            Response.Redirect("~/Pages/Companies/ViewJoseekrProf.aspx");
        }

        protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["email2"] = GridView3.SelectedRow.Cells[4].Text;
            Response.Redirect("~/Pages/Companies/ViewJoseekrProf.aspx");
        }

        protected void GridView4_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["email2"] = GridView4.SelectedRow.Cells[4].Text;
            Response.Redirect("~/Pages/Companies/ViewJoseekrProf.aspx");
        }
    }
}