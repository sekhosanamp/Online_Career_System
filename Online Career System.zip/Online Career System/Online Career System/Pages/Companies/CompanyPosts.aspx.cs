﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Companies
{
    public partial class CompanyPosts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Session["PostRef"] = "";
            }

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["PostRef"] = GridView1.SelectedRow.Cells[1].Text;
            Response.Redirect("~/Pages/Companies/UpdatePost.aspx");

        }

        protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            Session["PostRef"] = GridView1.SelectedRow.Cells[2].Text;
            Response.Redirect("~/Pages/Companies/UpdatePost.aspx");
        }

        protected void Image1_Click(object sender, ImageClickEventArgs e)
        {


            //SqlDataSource1.FilterParameters.Add(new System.Web.UI.WebControls.ControlParameter("PostRef", "txtSearch","Text"));
            //SqlDataSource1.FilterParameters[0].ConvertEmptyStringToNull = true;
        }
    }
}