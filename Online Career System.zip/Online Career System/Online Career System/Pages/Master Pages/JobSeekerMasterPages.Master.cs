﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Master_Pages
{
    public partial class JobSeekerMasterPages : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            try
            {
                if (!IsPostBack)
                {



                    string strname = Session["firstname"].ToString();
                    string strlname = Session["lastname"].ToString();

                    if (strlname.Length > 0)
                    {
                        lblstatus.Text = "WELCOME " + strlname.ToUpper() + " " + strname.ToUpper();

                    }
                    else
                    {
                        Response.Redirect("/Pages/Home/Jobseekerlogin.aspx");
                    }

                }
            }
            catch (Exception ec)
            {
                Response.Redirect("/Pages/Home/Jobseekerlogin.aspx");

            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["firstname"] = "";
            Session["lastname"] = "";
            Session["email"] = "";

            // window.onload = window.history.forward(0);  //calling function on window onload
          

            Response.Redirect("~/Pages/Home/Jobseekerlogin.aspx");
        }
    }
}