﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Master_Pages
{
    public partial class AfterloginCompanyMasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    string stremail = Session["companyemail"].ToString();
                    string companame = Session["companyname"].ToString();


                    if (stremail.Length > 0)
                    {
                        lblstatus.Text = "WELCOME " + companame;

                    }
                    else
                    {
                        Response.Redirect("/Pages/Companies/CompanySignin.aspx");
                    }

                }
            }
            catch (Exception ec)
            {

                Response.Redirect("/Pages/Companies/CompanySignin.aspx");

            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["companyemail"] = "";
            Session["companyname"] = "";
            Response.Redirect("/Pages/Companies/CompanySignin.aspx");
        }
    }
}