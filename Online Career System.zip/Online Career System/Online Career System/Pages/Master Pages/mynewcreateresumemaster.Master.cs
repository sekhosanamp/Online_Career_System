﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages.Master_Pages
{
    public partial class mynewcreateresumemaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {



                    string strname = Session["firstname"].ToString();
                    string strlname = Session["lastname"].ToString();

                    if (strlname.Length > 0)
                    {
                      
                    }
                    else
                    {
                        Response.Redirect("/Pages/Home/Jobseekerlogin.aspx");
                    }

                }
            }
            catch (Exception ec)
            {
                Response.Redirect("/Pages/Home/Jobseekerlogin.aspx");

            }
        }
    }
}