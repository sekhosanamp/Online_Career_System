﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Pages
{
    public partial class FeedBackForJobseekr : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtDescription.Text = "";
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "insertFeedback2";

                cmd.Parameters.AddWithValue("@subj", "Feed Back from Job Seeker");
                cmd.Parameters.AddWithValue("@desc ", txtDescription.Text);
                cmd.Parameters.AddWithValue("@js_email",Session["email"].ToString());

                cmd.ExecuteNonQuery();
                con.Close();

                string script = "alert(\"FeedBack is successfully sent ,Thank you for your time\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);

                txtDescription.Text = "";

            }
            catch (Exception ex)
            {
                string script = "alert(\"An error has occured , we could'nt receive your feedback please try again later\");";
                ScriptManager.RegisterStartupScript(this, GetType(),
                                      "ServerControlScript", script, true);
            }
        }
    }
}