﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System.Job_Seeker
{
    public partial class ViewJob : System.Web.UI.Page
    {
        private string strjobtitle;
        private string strLocation;
        private string strjMaxSal;
        private string strjMinSal;
        private string strSalaryType;
        private string strSalNigo;
        private string strSectors;
        private string strPostedDate;
        private string strjobRef;
        private string strJobduties;
        private string strCandidateReq;
        private string strClosingDate;
        private string strprovince;
        private string strBonuses;
        private string strCommision;
        private string strApplyVia;
        private string strEmailOrSite;
        private string strOtherBenefits;
        private string strEmpType;

        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {

                LabelBenefits.Visible = false;
                lstbenefits.Visible = false;
                try
                {
                    UpdateNoOFviews();

                    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                    SqlDataReader reader;
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "Select * from PostDetails where PostID = '" + Session["PostID"].ToString() + "'";
                    cmd.ExecuteNonQuery();


                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        strjobtitle = reader.GetValue(1).ToString();
                        strjobRef = reader.GetValue(2).ToString();
                        strJobduties = reader.GetValue(3).ToString();
                        strCandidateReq = reader.GetValue(4).ToString();
                        strSectors = reader.GetValue(5).ToString();
                         strprovince = reader.GetValue(7).ToString();
                        strLocation = reader.GetValue(8).ToString();
                        strSalaryType = reader.GetValue(9).ToString();
                        strjMinSal = reader.GetValue(10).ToString();
                        strjMaxSal = reader.GetValue(11).ToString();
                        strSalNigo = reader.GetValue(12).ToString();
                        strBonuses = reader.GetValue(13).ToString();
                        strCommision = reader.GetValue(15).ToString();
                        strClosingDate = reader.GetValue(18).ToString();
                        strApplyVia = reader.GetValue(20).ToString();
                        strEmailOrSite = reader.GetValue(21).ToString();
                        strOtherBenefits = reader.GetValue(26).ToString();
                        strEmpType = reader.GetValue(27).ToString();



                    }
                    reader.Close();
                    con.Close();


                    lblTitle.Text = strjobtitle;
                    lbllocation.Text = strprovince + " - " + strLocation + " , " + strjMinSal + " - " + strjMaxSal + " " + strSalaryType;
                    lblJobType.Text = "Employment Type : " + strEmpType;
                    lblSector.Text = "Sector(s) : " + strSectors;
                    lblRef.Text = "Reference : " + strjobRef;

                    // DateTime da = new DateTime();

                    double da = (Convert.ToDateTime(strClosingDate) - DateTime.Today).TotalDays;
                    lblapplyBefore.Text = "Apply Before " + strClosingDate +" ," + da + " days left " ;
                    lblDuties.Text = strJobduties;
                    lblRequirements.Text = strCandidateReq;
                    lblNoOfViews.Text = NumOfViews().ToString() + " people have viewed this job";



                 

                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }


                try
                {
                    if (strBonuses.Length > 1)
                    {
                        LabelBenefits.Visible = true;
                        lstbenefits.Visible = true;
                        lstbenefits.Items.Clear();
                        string line = strBonuses;
                        string w;
                        int index;

                        for (int x = 0; x < 1000; x++)
                        {
                            index = line.IndexOf(",");
                            w = line.Substring(0, index);
                            lstbenefits.Items.Add(w);
                            line = line.Remove(0, index + 1);

                        }
                    }
                    else
                    {
                        LabelBenefits.Visible = false;
                        lstbenefits.Visible = false;
                    }

                }
                catch (Exception)
                {
                    LabelBenefits.Visible = false;
                    lstbenefits.Visible = false;

                }


            }
        }

        public int NumOfViews()
        {
            int CountNum = 0;

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select * from postcountsdetails where postid = '" + Session["PostId"] + "'";

                SqlDataReader dr;
                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    CountNum =Convert.ToInt32( dr.GetValue(1).ToString());
                }
                dr.Close();
               
                
                con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

            return CountNum;
        }

        public void UpdateNoOFviews ()
        {

            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());

                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = "UpdateNoOfviews";

                cmd.Parameters.AddWithValue("@postId", Session["PostID"].ToString());

                cmd.ExecuteNonQuery();
                 con.Close();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {

            try
            {
                UpdateNoOFviews();

                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OurConnection"].ToString());
                SqlDataReader reader;
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Select * from PostDetails where PostID = '" + Session["PostID"].ToString() + "'";
                cmd.ExecuteNonQuery();


                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
            
                    strApplyVia = reader.GetValue(20).ToString();
                    strEmailOrSite = reader.GetValue(21).ToString();
                  


                }
                reader.Close();
                con.Close();
                if (strApplyVia.Equals("External Website "))
                {
                    Response.Redirect(strEmailOrSite);
                }
                else
                {
                    SendMail();
                }


            }
            catch (Exception)
            {
                LabelBenefits.Visible = false;
                lstbenefits.Visible = false;

            }



        

        }


        protected void SendMail()
        {
            try
            {

                // Gmail Address from where you send the mail
                var fromAddress = "SekhosanaMP@gmail.com";
                // any address where the email will be sending
                var toAddress = "Makhado23@gmail.com";
                //Password of your gmail address
                const string fromPassword = "sekhosana2138763831";
                // Passing the values and make a email formate to display
                string subject = "Testing Email";
                string body = "From  my body: ";

                // smtp settings
                var smtp = new System.Net.Mail.SmtpClient();
                {
                    smtp.Host = "smtp.gmail.com";
                    smtp.Port = 465;
                    smtp.EnableSsl = true;
                    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    smtp.Credentials = new NetworkCredential(fromAddress, fromPassword);
                    smtp.Timeout = 80000;
                }
                // Passing values to smtp object
                smtp.Send(fromAddress, toAddress, subject, body);
                Response.Write("Email Sent");
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
    }
