﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Career_System
{
    public partial class TestImage : System.Web.UI.Page
    {
        List<string> lstjobtitles;
        List<string> lstjoblocation;
        List<string> lstjobSectors;
        List<string> lstSalaryRange;
        List<string> lstjobType;
        List<string> lstjobDesc;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
           
        }
    }
}